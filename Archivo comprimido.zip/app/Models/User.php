<?php

namespace App\Models;

use DateTime;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class User extends Model{
    // public ?int $id = null;
    // public string $nombre;
    // public string $apellidos;
    // public string $mail;
    // public string $telefono;
    // public string $sexo;
    // public bool $admin;
    // public bool $superAdmin;
    // public int $venue_id;
    // public bool $departamento;
    // public bool $working;


    //  public string $fAlta;
    //  public string $fBaja;
    // public string $password;
    // public int $role_id;

    // public ?int $piso_id;
    // public ?int $puerta_id;


    public function piso(): BelongsTo{
        return $this->belongsTo(Piso::class);
    }
    public function puerta(): BelongsTo{
        return $this->belongsTo(Puerta::class);
    }

    public function role(): BelongsTo {
        return $this->belongsTo(Role::class);
    }
    public function incs(): HasMany{
        return $this->hasMany(Inc::class);
    }
    
    


};

        