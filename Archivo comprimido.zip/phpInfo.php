<?php

use Illuminate\Support\Facades\Date;

$in = '2023-10-14';
$out = '2025-10-25';

print_r(new DateTime('now'));